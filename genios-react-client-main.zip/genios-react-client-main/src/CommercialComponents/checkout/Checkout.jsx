const Checkout = () => {
  return (
    <div>
      <h1>Esto es el checkout o página para compra</h1>
      <a href="/catalog">Volver al catálogo</a>
    </div>
  )
}

export { Checkout }
