const ProductDetail = ({ product }) => {
  return (
    <>
      <h1>DIALOG</h1>
    </>
  )
}
