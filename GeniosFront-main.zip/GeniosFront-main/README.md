# GeniosFront

Prototipos en código estático para las interfaces de la aplicación Genios SoftGAC

Para que el proyecto pueda verse correctamente, instalar browser-sync y ejecutar el
siguiente comando

    browser-sync start --server --files="**/*"

Se ha creado una pequeña mascara de comandos con Makefile

    make setup : instalar dependencia browser-sync
    make dev : crear un server local para visualizar el proyecto

[link a página de visualización](https://geniossoftgac.github.io/GeniosFront/index.html)
