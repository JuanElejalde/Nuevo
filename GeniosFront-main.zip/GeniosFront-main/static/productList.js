export const products = [
  {
    name: 'Carrito',
    image: './images/carritoMadera.jpg',
    price: 20000,
  },
  {
    name: 'Trensito',
    image: './images/Trensito.jpg',
    price: 50000,
  },
  {
    name: 'Casita',
    image: './images/casita.jpg',
    price: 90000,
  },
  {
    name: 'perro',
    image: './images/perro.jpg',
    price: 150000,
  },
  {
    name: 'ardilla',
    image: './images/ardilla.jpg',
    price: 250000,
  },
  {
    name: 'carrito de compra',
    image: './images/carritodecompra.jpg',
    price: 260000,
  },
  {
    name: 'elefante',
    image: './images/elefante.png',
    price: 150000,
  },
  {
    name: 'grua',
    image: './images/grua.jpg',
    price: 400000,
  },
  {
    name: 'avión',
    image: './images/avion.jpg',
    price: 180000,
  },
  {
    name: 'moto',
    image: './images/moto.jpg',
    price: 200000,
  },
  {
    name: 'camión',
    image: './images/camion.jpg',
    price: 350000,
  },
  {
    name: 'grillo',
    image: './images/grillo.jpg',
    price: 500000,
  },
  {
    name: 'caballo',
    image: './images/caballo.jpg',
    price: 130000,
  },
  {
    name: 'helicoptero',
    image: './images/helicoptero.jpg',
    price: 450000,
  },
  {
    name: 'pato',
    image: './images/pato.jpg',
    price: 250000,
  },
]
